# Unified Roblox Bot

A simple unified bot program that combines the Forage Bot and Reincarnation Bot into one application with an easy-to-use bot selector.

## Features

- **Bot Selector**: Simple dropdown to choose between Forage Bot or Reincarnation Bot
- **Single Hotkey**: F6 to start/stop whichever bot is selected
- **Easy Calibration**: Built-in calibration tool for both bots
- **Status Display**: Shows which bot is running and logs all activity
- **Simple GUI**: Clean Tkinter interface with minimal complexity

## Installation

1. **Install Python 3.8 or higher** if you don't have it already

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **For Reincarnation Bot**: Install Tesseract OCR
   - Download from: https://github.com/UB-Mannheim/tesseract/wiki
   - Install to default location: `C:\Program Files\Tesseract-OCR\`

4. **Copy template.png**: Make sure `template.png` is in the same folder as `unified_bot.py` (needed for Forage Bot)

## Usage

### Starting the Bot

1. Run the program:
   ```bash
   python unified_bot.py
   ```

2. Select which bot you want to use from the dropdown menu

3. Click "Calibrate" to set up the selected bot (required on first use)

4. Press **F6** or click "Start Bot" to begin

5. Press **F6** again to stop the bot

### Calibrating Forage Bot

When you click "Calibrate" with Forage Bot selected:

1. **Select Game Area**: Click and drag to select the area where targets appear
2. **Click Left Arrow**: Click on the left navigation arrow in the game
3. **Click Right Arrow**: Click on the right navigation arrow in the game

Settings are saved to `forage_settings.json`

### Calibrating Reincarnation Bot

When you click "Calibrate" with Reincarnation Bot selected, you'll be prompted to click on each button in order:

1. **Stats Button**: The button that opens the stats page
2. **Options Button**: The button that opens options
3. **Reincarnate Button**: The first reincarnate button
4. **Yes Confirm Button**: The confirmation button
5. **Skip Animation Button**: The skip animation button (if available)
6. **Reincarnate Final Button**: The final reincarnate button

Settings are saved to `rein_settings.json`

## Hotkeys

- **F6**: Start/Stop the currently selected bot

## Files Created

- `forage_settings.json` - Forage Bot calibration and settings
- `rein_settings.json` - Reincarnation Bot calibration and settings

## Troubleshooting

### Forage Bot Issues

- **"template.png not found"**: Make sure `template.png` is in the same folder as `unified_bot.py`
- **Bot not finding targets**: Try recalibrating the game area
- **Bot clicking wrong spots**: Adjust the detection threshold in `forage_settings.json`

### Reincarnation Bot Issues

- **OCR not working**: Make sure Tesseract is installed at `C:\Program Files\Tesseract-OCR\`
- **Bot clicking wrong buttons**: Recalibrate the button positions
- **Bot too fast/slow**: Adjust wait times in `rein_settings.json`

### General Issues

- **Hotkey not working**: Make sure the program window is not minimized
- **Bot stops unexpectedly**: Check the log window for error messages
- **Calibration cancelled**: Press ESC during calibration to cancel and try again

## Tips

- Always focus the game window before starting the bot
- Make sure the game is in the correct state before starting (e.g., in-game for Forage Bot)
- Use the log window to monitor bot activity
- You can switch between bots without restarting the program

## Requirements

- Python 3.8+
- Windows OS (for pydirectinput and keyboard libraries)
- Tesseract OCR (for Reincarnation Bot only)
- See `requirements.txt` for Python package dependencies

## Notes

- Only one bot can run at a time
- Settings are saved automatically after calibration
- The bot will stop if it encounters an error (check the log)
- Press F6 to stop the bot at any time